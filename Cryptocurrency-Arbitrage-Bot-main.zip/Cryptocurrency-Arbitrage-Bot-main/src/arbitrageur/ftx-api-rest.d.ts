declare module "ftx-api-rest"
